#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

use serde::Serialize;

#[derive(Serialize)]
struct CursorPosition {
    x: f64,
    y: f64,
}

/// Get the pointer relative to the Tauri content area in CSS (logical) pixels.
/// Tauri returns physical screen coordinates for both pointer and window, so
/// subtract first, then divide by the window's current DPI scale factor.
/// Works even when the pointer is outside our always-on-top window.
#[tauri::command]
fn get_cursor_relative(window: tauri::WebviewWindow) -> Result<CursorPosition, String> {
    let cursor = window.cursor_position().map_err(|e| e.to_string())?;
    let client = window.inner_position().map_err(|e| e.to_string())?;
    let scale = window.scale_factor().map_err(|e| e.to_string())?;
    if !scale.is_finite() || scale <= 0.0 {
        return Err("invalid window scale factor".into());
    }
    Ok(CursorPosition {
        x: (cursor.x - f64::from(client.x)) / scale,
        y: (cursor.y - f64::from(client.y)) / scale,
    })
}

fn main() {
    tauri::Builder::default()
        .invoke_handler(tauri::generate_handler![get_cursor_relative])
        .run(tauri::generate_context!())
        .expect("failed to start Codex Conan Pet");
}
