# 柯南 × Codex 桌宠 v0.2（Windows 10 个人本地版）

基于原来的 v0.1 Tauri 2 + React + TypeScript 项目升级。本版可显示一只常驻桌面的柯南，支持 6 种模拟工作状态、透明窗口、拖动、**跨桌面的鼠标视线跟随、平滑眼球移动、随机眨眼**。

**目前仍是状态模拟器。** 尚未接入实际 Codex 进程、Hooks 或 App Server，不能自动判断 Codex 是否真的在工作。

> 柯南角色素材仅用于你自己的本地研究；未经许可请勿公开传播或商业使用相关形象素材。

## 先验证效果（零安装）

解压后双击 `预览演示.bat`，也可以直接用 Edge/Chrome 打开 `demo.html`。

- 把鼠标在网页上移动，柯南瞳孔会平滑看向鼠标。
- 鼠标停止后视线平滑停下，随机间隔约 **2.7–6.3 秒** 自动眨眼。
- 可点击「眼球追踪」「自然眨眼」开关，或点击「眨眼一次」测试。
- 点击角色、状态按钮或键盘 `1`~`6` 切换姿势；空格循环切换，`B` 手动眨眼（浏览器演示支持）。
- 演示中的**鼠标跟随范围只限网页内**。浏览器安全限制不允许读取整个 Windows 桌面的鼠标位置。
- 浏览器演示没有透明 Windows 桌面置顶、原生拖动或全局鼠标读取。

## Windows 10：运行真正的桌宠

先安装：

1. [Node.js LTS](https://nodejs.org/)（推荐 20+）
2. [Rust MSVC 工具链](https://rustup.rs/)（`x86_64-pc-windows-msvc`）
3. [Microsoft Visual Studio C++ Build Tools](https://visualstudio.microsoft.com/visual-cpp-build-tools/)（勾选“使用 C++ 的桌面开发”及 Windows SDK）
4. [Microsoft Edge WebView2 Runtime](https://developer.microsoft.com/microsoft-edge/webview2/)（Windows 10 未预装时安装）

依赖需要联网安装一次。安装后在项目根目录双击：

**`启动桌宠-Windows.bat`**

或 CMD / PowerShell 执行：

```powershell
npm install
npm run tauri dev
```

启动后桌宠透明窗口会常驻最前。鼠标**即使移到桌宠窗口之外**，仍会更新视线（Tauri Rust 端取得指针相对桌宠内容区的位置）；这不依赖键盘焦点，不需要安装低级鼠标钩子。

通过顶部 `⠿ CONAN.CODEX` 把手拖动窗口，移动后坐标自动更新。支持 Windows 10 常用 DPI 缩放（包括多个显示器的物理坐标转换）；极端混合 DPI 环境仍建议实机测试。

## 使用操作

| 操作 | 作用 |
| --- | --- |
| 拖动顶部标题把手 | 移动 Windows 桌宠窗口 |
| 鼠标移到屏幕不同位置 | 眼球平滑跟随（桌面版全局） |
| 点击「眼球追踪 开/关」 | 关闭时眼球平滑恢复居中 |
| 点击「自然眨眼 开/关」 | 启用/禁用随机眨眼 |
| 点击「眨眼一次」 | 单次眨眼测试 |
| 点击柯南、`1`~`6`、空格 | 手动切换 6 种模拟状态 |
| 「自动演示」 | 循环切换模拟状态 |
| 顶部 `− / +` | 收起/展开控制区 |
| 顶部 `×` | 退出桌宠 |

所有 6 种姿势都支持动态瞳孔；庆祝姿势源图已有一只眼闭着，因此只移动另一只睁开的眼睛。

## 角色素材如何实现眼球跟随

原始状态图片是 512×512 的完整 PNG，并非天然支持独立瞳孔。v0.2 把每张状态图拆成：

- `public/pet/gaze/{state}-base.png`：眼白已修复的身体及面部底图。
- `public/pet/gaze/{state}-iris-0.png` 和 `iris-1.png`：从原图精确定位并抠出的原始瞳孔层。
- `public/pet/gaze/{state}-blink.png`：单独的闭眼覆盖层。
- `src/lib/gazeMeta.ts`：与所有素材注册在同一 512px 坐标系中的眼睛坐标。

运行时只给瞳孔应用 `translate3d`，不重排 React 组件。使用 `requestAnimationFrame` 与指数平滑插值，模拟有惯性的视线。默认最大偏移约相当于原图的 10px（水平方向）/7px（垂直方向），避免瞳孔离开眼白太远。

### Windows 全局鼠标数据的来源

1. `src-tauri/src/main.rs` 的 `get_cursor_relative` 调用 Tauri 窗口 `cursor_position()`、`inner_position()` 和 `scale_factor()`。
2. 每约 38ms 返回一个坐标到前端（实际间隔还受到异步调用开销影响）。
3. `src/lib/usePointerGaze.ts` 按眼睛位置求瞳孔目标向量，每帧平滑插值。
4. 应用只在本地读取当前指针坐标，**不写入日志、不上传位置、不监控点击内容**。
5. 当桌面接口连续失败时退回窗口内跟随。纯浏览器演示仅处理网页内的 pointermove。

随机眨眼由浏览器定时器驱动，没有联网或 AI 推理。

## 构建 Windows 安装包

双击 `打包Windows安装包.bat`，或者执行：

```powershell
npm install
npm run tauri build
```

安装程序一般在 `src-tauri/target/release/bundle/nsis/` 中。

**当前交付为完整源码及浏览器演示，并不包含事先编译的 Windows EXE。** 请在安装好上述环境的 Windows 10 电脑上构建。

## 文件结构

```text
codex-conan-pet/
├─ demo.html                       # 独立零安装浏览器演示：鼠标跟随/眨眼/状态
├─ 启动桌宠-Windows.bat
├─ 预览演示.bat
├─ 打包Windows安装包.bat
├─ public/pet/*.png                # V0.1 原始六种角色素材
├─ public/pet/gaze/*.png           # V0.2 分层素材（眼白/虹膜/眨眼）
├─ scripts/build_eye_assets.py     # 从旧素材重新生成眼睛分层（可选）
├─ src/
│  ├─ App.tsx                      # 控制按钮、状态模拟
│  ├─ components/Pet.tsx           # 注册眼睛素材、自然眨眼
│  ├─ lib/usePointerGaze.ts        # 全局鼠标采样/平滑动画
│  ├─ lib/gazeMeta.ts              # 每种姿势的眼球注册坐标
│  └─ styles/main.css             # 透明窗口和动画
└─ src-tauri/
   ├─ src/main.rs                 # Tauri 原生全局指针读取命令
   └─ tauri.conf.json             # 透明置顶窗口、打包配置
```

> 正常使用不需要 Python。只有需要重新切割角色图层时，才需要 `pip install pillow`，再运行 `python scripts/build_eye_assets.py`。如果换一套素材，需要手动调整该脚本中每只眼睛的坐标。

## 验收建议

在真实 Windows 10 上：启动后把鼠标分别移动到窗口四角之外；改变桌宠所在位置；拖动到副显示器（若有）；在 100%、125%、150% 缩放下观察视线方向；手动测试 6 个状态；关闭自动眨眼；最后退出程序验证不再运行。

如果启动失败：先检查 Node/Cargo/MSVC/SDK/WebView2 是否安装，优先在项目根目录运行 `npm run tauri dev` 查看完整错误日志。

参考：[Tauri 2 前置要求](https://v2.tauri.app/start/prerequisites/) · [调用 Rust 命令](https://v2.tauri.app/develop/calling-rust/) · [WebviewWindow API](https://docs.rs/tauri/latest/tauri/webview/struct.WebviewWindow.html)
