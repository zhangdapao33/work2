@echo off
chcp 65001 >nul
cd /d "%~dp0"
title Codex Conan Pet - Development
where node >nul 2>nul
if errorlevel 1 (
  echo [错误] 没有找到 Node.js。请先安装 Node.js LTS。
  goto finish
)
where cargo >nul 2>nul
if errorlevel 1 (
  echo [错误] 没有找到 Rust/Cargo。请先安装 Rust MSVC 工具链与 Visual C++ Build Tools。
  goto finish
)
if not exist "node_modules" (
  echo [1/2] 首次安装前端依赖...
  call npm install
  if errorlevel 1 goto failed
)
echo [2/2] 启动透明桌宠窗口...
call npm run tauri dev
if errorlevel 1 goto failed
goto finish
:failed
echo [错误] 启动失败，请阅读 README.md 的环境与排障说明。
:finish
pause
