export const PET_STATES = [
  "idle",
  "thinking",
  "working",
  "attention",
  "complete",
  "error",
] as const;

export type PetState = (typeof PET_STATES)[number];

export interface PetStateDefinition {
  id: PetState;
  label: string;
  tag: string;
  speech: string;
  image: string;
  icon: string;
}

export const PET_DEFINITIONS: Record<PetState, PetStateDefinition> = {
  idle: {
    id: "idle", label: "待机", tag: "IDLE", speech: "今天又有什么谜题？", image: "/pet/idle.png", icon: "◌",
  },
  thinking: {
    id: "thinking", label: "思考", tag: "THINKING", speech: "让我想一想……", image: "/pet/thinking.png", icon: "?",
  },
  working: {
    id: "working", label: "工作", tag: "WORKING", speech: "正在分析代码线索！", image: "/pet/working.png", icon: "⌘",
  },
  attention: {
    id: "attention", label: "提醒", tag: "ATTENTION", speech: "有件事需要你确认！", image: "/pet/attention.png", icon: "!",
  },
  complete: {
    id: "complete", label: "完成", tag: "COMPLETE", speech: "案件解决！", image: "/pet/complete.png", icon: "✓",
  },
  error: {
    id: "error", label: "失败", tag: "ERROR", speech: "这里好像有问题……", image: "/pet/error.png", icon: "×",
  },
};

export const PET_DEMO_SEQUENCE: PetState[] = [
  "idle", "thinking", "working", "attention", "working", "complete", "idle", "thinking", "error",
];
