import { create } from "zustand";
import type { PetState } from "./pet";

type PetStore = {
  state: PetState;
  history: PetState[];
  setState: (next: PetState) => void;
};

export const usePetStore = create<PetStore>((set) => ({
  state: "idle",
  history: ["idle"],
  setState: (next) => set((current) => ({
    state: next,
    history: [...current.history.slice(-11), next],
  })),
}));
