import { useEffect, type RefObject } from "react";
import { invoke, isTauri } from "@tauri-apps/api/core";
import { GAZE_META } from "./gazeMeta";
import type { PetState } from "./pet";

interface PointerPosition { x: number; y: number }

// The sprite is a square 512x512 canvas, rendered as a 230x230 CSS box.
const SOURCE_SIZE = 512;
const MAX_X = 10;  // px at original image resolution
const MAX_Y = 7;
const SATURATION_DISTANCE = 130; // CSS px
const RELAX_TIME_MS = 92;

/**
 * Tracks pointer across Windows desktop in Tauri, with an in-page browser fallback.
 * Iris transforms are written directly at animation-frame frequency: React never
 * re-renders for individual pointer samples. The Rust command takes only local
 * coordinates; no OS-level mouse hooking, logging or network access is needed.
 */
export function usePointerGaze(
  state: PetState,
  enabled: boolean,
  artRef: RefObject<HTMLDivElement | null>,
  irisRefs: RefObject<Array<HTMLImageElement | null>>,
): void {
  useEffect(() => {
    let alive = true;
    let pollingTimer = 0;
    let frame = 0;
    let lastFrame = 0;
    const target: PointerPosition = { x: Number.NaN, y: Number.NaN };
    const smoothed = { x: 0, y: 0 };
    const native = isTauri();
    let errors = 0;

    function onMove(ev: PointerEvent) {
      // Browser demo tracks inside its own page; the Tauri command overrides this
      // with global screen coordinates, including when the window is unfocused.
      if (!native || errors >= 3) {
        target.x = ev.clientX;
        target.y = ev.clientY;
      }
    }
    function onLeave() {
      if (!native) { target.x = Number.NaN; target.y = Number.NaN; }
    }
    window.addEventListener("pointermove", onMove, { passive: true });
    document.addEventListener("pointerleave", onLeave);

    async function pollGlobalCursor() {
      if (!alive || !enabled || !native || errors >= 3) return;
      try {
        const pos = await invoke<PointerPosition>("get_cursor_relative");
        if (!alive) return;
        if (Number.isFinite(pos.x) && Number.isFinite(pos.y)) {
          target.x = pos.x;
          target.y = pos.y;
        }
        errors = 0;
      } catch (err) {
        errors += 1;
        if (errors === 3) console.warn("全局指针读取失败，退回窗口内追踪：", err);
      }
      if (alive && errors < 3) pollingTimer = window.setTimeout(pollGlobalCursor, 38);
    }

    function animate(now: number) {
      if (!alive) return;
      const art = artRef.current;
      let desiredX = 0;
      let desiredY = 0;
      if (art && enabled && Number.isFinite(target.x) && Number.isFinite(target.y)) {
        const rect = art.getBoundingClientRect();
        const meta = GAZE_META[state];
        const eyeX = rect.left + meta.aimX * rect.width / SOURCE_SIZE;
        const eyeY = rect.top + meta.aimY * rect.height / SOURCE_SIZE;
        const deltaX = target.x - eyeX;
        const deltaY = target.y - eyeY;
        const distance = Math.hypot(deltaX, deltaY);
        const divider = Math.max(SATURATION_DISTANCE, distance);
        desiredX = deltaX / divider * MAX_X * rect.width / SOURCE_SIZE;
        desiredY = deltaY / divider * MAX_Y * rect.height / SOURCE_SIZE;
      }

      const deltaMs = Math.min(64, Math.max(0, now - (lastFrame || now)));
      lastFrame = now;
      const blend = 1 - Math.exp(-deltaMs / RELAX_TIME_MS);
      smoothed.x += (desiredX - smoothed.x) * blend;
      smoothed.y += (desiredY - smoothed.y) * blend;
      irisRefs.current.forEach((img) => {
        if (img) img.style.transform = `translate3d(${smoothed.x.toFixed(2)}px, ${smoothed.y.toFixed(2)}px, 0)`;
      });
      frame = window.requestAnimationFrame(animate);
    }

    if (native && enabled) void pollGlobalCursor();
    frame = window.requestAnimationFrame(animate);
    return () => {
      alive = false;
      window.clearTimeout(pollingTimer);
      window.cancelAnimationFrame(frame);
      window.removeEventListener("pointermove", onMove);
      document.removeEventListener("pointerleave", onLeave);
    };
  }, [artRef, enabled, irisRefs, state]);
}
