import { isTauri } from "@tauri-apps/api/core";
import { getCurrentWindow, LogicalSize } from "@tauri-apps/api/window";

export const isDesktop = () => isTauri();

export async function dragWindow(): Promise<void> {
  if (!isDesktop()) return;
  await getCurrentWindow().startDragging();
}

export async function resizeForPanel(expanded: boolean): Promise<void> {
  if (!isDesktop()) return;
  await getCurrentWindow().setSize(new LogicalSize(324, expanded ? 472 : 310));
}

export async function quitApp(): Promise<void> {
  if (!isDesktop()) return;
  await getCurrentWindow().close();
}
