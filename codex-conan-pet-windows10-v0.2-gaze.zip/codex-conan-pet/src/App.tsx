import { useCallback, useEffect, useRef, useState } from "react";
import Pet from "./components/Pet";
import { PET_DEFINITIONS, PET_DEMO_SEQUENCE, PET_STATES, type PetState } from "./lib/pet";
import { usePetStore } from "./lib/petStore";
import { dragWindow, quitApp, resizeForPanel, isDesktop } from "./lib/window";

function reportError(err: unknown) {
  console.error("窗口操作未完成：", err);
}

export default function App() {
  const state = usePetStore((s) => s.state);
  const setPetState = usePetStore((s) => s.setState);
  const history = usePetStore((s) => s.history);
  const [expanded, setExpanded] = useState(true);
  const [autoplay, setAutoplay] = useState(false);
  const [gazeEnabled, setGazeEnabled] = useState(true);
  const [blinkEnabled, setBlinkEnabled] = useState(true);
  const [blinkRequest, setBlinkRequest] = useState(0);
  const sequenceIndex = useRef(0);
  const current = PET_DEFINITIONS[state];
  const trackingScope = isDesktop() ? "Windows 全桌面" : "当前网页";

  const goNext = useCallback(() => {
    const i = PET_STATES.indexOf(usePetStore.getState().state);
    setPetState(PET_STATES[(i + 1) % PET_STATES.length]);
  }, [setPetState]);

  useEffect(() => {
    if (!autoplay) return;
    const id = window.setInterval(() => {
      sequenceIndex.current = (sequenceIndex.current + 1) % PET_DEMO_SEQUENCE.length;
      setPetState(PET_DEMO_SEQUENCE[sequenceIndex.current]);
    }, 1700);
    return () => window.clearInterval(id);
  }, [autoplay, setPetState]);

  useEffect(() => {
    function onKeyDown(e: KeyboardEvent) {
      const target = e.target as HTMLElement;
      if (target.tagName === "INPUT" || target.tagName === "TEXTAREA") return;
      if (/^[1-6]$/.test(e.key)) {
        setAutoplay(false);
        setPetState(PET_STATES[Number(e.key) - 1]);
      }
      if (e.code === "Space") {
        e.preventDefault();
        setAutoplay(false);
        goNext();
      }
      if (e.key === "Escape") {
        void resizeForPanel(false).then(() => setExpanded(false)).catch(reportError);
      }
    }
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [goNext, setPetState]);

  async function togglePanel() {
    const next = !expanded;
    try {
      await resizeForPanel(next);
      setExpanded(next);
    } catch (err) {
      reportError(err);
    }
  }

  function chooseState(next: PetState) {
    setAutoplay(false);
    sequenceIndex.current = PET_DEMO_SEQUENCE.indexOf(next);
    if (sequenceIndex.current < 0) sequenceIndex.current = 0;
    setPetState(next);
  }

  function toggleAutoplay() {
    if (!autoplay) {
      sequenceIndex.current = 0;
      setPetState(PET_DEMO_SEQUENCE[0]);
    }
    setAutoplay((prev) => !prev);
  }

  return (
    <main className={`shell shell--${state}${expanded ? "" : " shell--compact"}`}>
      <header className="toolbar">
        <div
          className="drag-handle"
          onMouseDown={(e) => { if (e.button === 0) void dragWindow().catch(reportError); }}
          title="按住此处拖动桌宠"
          aria-label="拖动窗口区域"
        >
          <span className="drag-dots" aria-hidden="true">⠿</span>
          <span className="brand">CONAN<span className="brand-period">.</span>CODEX</span>
        </div>
        <span className="live-chip"><span className="chip-light" />模拟模式</span>
        <button className="toolbar-action" type="button" onClick={() => void togglePanel()} aria-label={expanded ? "收起控制台" : "展开控制台"} title={expanded ? "收起控制台" : "展开控制台"}>{expanded ? "−" : "+"}</button>
        <button className="toolbar-action toolbar-action--close" type="button" onClick={() => void quitApp().catch(reportError)} aria-label="退出桌宠" title="退出桌宠">×</button>
      </header>

      <Pet state={state} gazeEnabled={gazeEnabled} blinkEnabled={blinkEnabled} blinkRequest={blinkRequest}
        onClick={() => { setAutoplay(false); goNext(); }} />

      {expanded && <section className="control-panel" aria-label="状态模拟控制台">
        <div className="panel-topline">
          <span className="panel-heading">状态模拟器</span>
          <span className={`status-tag status-tag--${state}`}>{current.tag}</span>
        </div>
        <div className="state-grid">
          {PET_STATES.map((id, index) => (
            <button className={`state-button${id === state ? " is-active" : ""}`} type="button" key={id} onClick={() => chooseState(id)} aria-pressed={id === state}>
              <span className="state-icon" aria-hidden="true">{PET_DEFINITIONS[id].icon}</span>
              <span>{PET_DEFINITIONS[id].label}</span>
              <span className="shortcut">{index + 1}</span>
            </button>
          ))}
        </div>
        <div className="gaze-options" aria-label="视线互动设置">
          <button type="button" className={`gaze-toggle${gazeEnabled ? " is-on" : ""}`}
            onClick={() => setGazeEnabled((v) => !v)} aria-pressed={gazeEnabled}
            title={`鼠标追踪范围：${trackingScope}`}>
            <span className="gaze-dot" />眼球追踪 {gazeEnabled ? "开" : "关"}
          </button>
          <button type="button" className={`gaze-toggle${blinkEnabled ? " is-on" : ""}`}
            onClick={() => setBlinkEnabled((v) => !v)} aria-pressed={blinkEnabled}>
            自然眨眼 {blinkEnabled ? "开" : "关"}
          </button>
          <button type="button" className="blink-test" onClick={() => setBlinkRequest((v) => v + 1)}>
            眨眼一次
          </button>
        </div>
        <div className="panel-footer">
          <button type="button" className={`autoplay-button${autoplay ? " is-playing" : ""}`} onClick={toggleAutoplay}>
            {autoplay ? "Ⅱ 停止演示" : "▶ 自动演示"}
          </button>
          <span className="event-count">{trackingScope} · 模拟 {Math.max(0, history.length - 1)} 次</span>
        </div>
      </section>}
      <footer className="micro-footer">LOCAL DEMO · 尚未连接真实 CODEX</footer>
    </main>
  );
}
