import { useEffect, useRef, useState } from "react";
import { GAZE_META } from "../lib/gazeMeta";
import { PET_DEFINITIONS, type PetState } from "../lib/pet";
import { usePointerGaze } from "../lib/usePointerGaze";

interface PetProps {
  state: PetState;
  onClick: () => void;
  gazeEnabled: boolean;
  blinkEnabled: boolean;
  blinkRequest: number;
}

const imageFor = (state: PetState, part: string) => `/pet/gaze/${state}-${part}.png`;

export default function Pet({ state, onClick, gazeEnabled, blinkEnabled, blinkRequest }: PetProps) {
  const definition = PET_DEFINITIONS[state];
  const artRef = useRef<HTMLDivElement>(null);
  const irisRefs = useRef<Array<HTMLImageElement | null>>([]);
  const [blinking, setBlinking] = useState(false);
  const blinkTimeout = useRef<number | undefined>(undefined);
  usePointerGaze(state, gazeEnabled, artRef, irisRefs);

  useEffect(() => {
    if (!blinkEnabled) return;
    let active = true;
    let scheduled = 0;
    const blink = () => {
      if (!active) return;
      setBlinking(true);
      blinkTimeout.current = window.setTimeout(() => {
        if (active) setBlinking(false);
        schedule();
      }, 130 + Math.random() * 55);
    };
    const schedule = () => {
      if (!active) return;
      scheduled = window.setTimeout(blink, 2700 + Math.random() * 3600);
    };
    schedule();
    return () => {
      active = false;
      window.clearTimeout(scheduled);
      window.clearTimeout(blinkTimeout.current);
      setBlinking(false);
    };
  }, [blinkEnabled]);

  // Manual one-shot blink to make the feature testable.
  useEffect(() => {
    if (blinkRequest === 0) return;
    setBlinking(true);
    const id = window.setTimeout(() => setBlinking(false), 175);
    return () => window.clearTimeout(id);
  }, [blinkRequest]);

  return (
    <div className={`pet-stage pet-stage--${state}`}>
      <div className="pet-halo" aria-hidden="true" />
      <button className="pet-character" type="button" onClick={onClick}
        title="点击柯南：切换到下一个状态"
        aria-label="点击角色，切换到下一个演示状态">
        <div className="pet-art" ref={artRef}>
          <img className="art-layer" src={imageFor(state, "base")} draggable={false} alt={`柯南 · ${definition.label}状态`} />
          {Array.from({ length: GAZE_META[state].count }, (_, index) => (
            <img key={`${state}-${index}`} ref={(node) => { irisRefs.current[index] = node; }}
              className="art-layer iris-layer" src={imageFor(state, `iris-${index}`)}
              alt="" aria-hidden="true" draggable={false} />
          ))}
          <img className={`art-layer eyelid-layer${blinking ? " is-blinking" : ""}`}
            src={imageFor(state, "blink")} alt="" aria-hidden="true" draggable={false} />
        </div>
      </button>
      <div className={`pet-speech pet-speech--${state}`} role="status" aria-live="polite" aria-atomic="true">
        <span className="speech-dot" />{definition.speech}
      </div>
    </div>
  );
}
