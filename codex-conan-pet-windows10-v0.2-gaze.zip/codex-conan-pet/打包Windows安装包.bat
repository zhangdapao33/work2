@echo off
chcp 65001 >nul
cd /d "%~dp0"
title Codex Conan Pet - Windows Installer
where node >nul 2>nul
if errorlevel 1 goto missing
where cargo >nul 2>nul
if errorlevel 1 goto missing
if not exist "node_modules" (
  call npm install
  if errorlevel 1 goto failed
)
call npm run tauri build
if errorlevel 1 goto failed
echo 已完成。安装包通常位于 src-tauri\target\release\bundle\nsis\
goto finish
:missing
echo 请先安装 Node.js、Rust MSVC、Visual C++ Build Tools 和 WebView2。
goto finish
:failed
echo 构建失败，请检查前置依赖与终端错误。
:finish
pause
