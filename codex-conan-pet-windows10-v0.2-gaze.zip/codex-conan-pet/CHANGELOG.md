# Changelog

## 0.2.0

- 保留 v0.1 的 Tauri 2 + React 桌宠、6 种角色状态、透明窗口与模拟切换。
- 新增 6 组眼白底图、原图瞳孔和闭眼覆盖图层（适配单眼眨眼的庆祝姿势）。
- 新增 Tauri Rust `get_cursor_relative`：全屏鼠标坐标、窗口内容区偏移、系统 DPI 缩放。
- 新增 requestAnimationFrame 平滑插值，不让鼠标采样频率触发 React 重渲染。
- 新增随机眨眼、视线/眨眼开关、单次眨眼测试。
- 浏览器零安装演示也支持鼠标页面内追踪和眨眼（不是全局追踪）。
- 仍为手动模拟的 Codex 状态，不包含真实 Codex 接入。
