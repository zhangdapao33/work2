"""Optional v0.2 image-layer consistency check; requires pillow."""
from pathlib import Path
from PIL import Image
import json

root = Path(__file__).resolve().parents[1]
gaze = root / 'public/pet/gaze'
manifest = json.loads((gaze / 'manifest.json').read_text(encoding='utf-8'))
assert set(manifest) == {'idle','thinking','working','attention','complete','error'}
count = 0
for state, meta in manifest.items():
    paths = [gaze / f'{state}-base.png', gaze / f'{state}-blink.png']
    paths += [gaze / f'{state}-iris-{i}.png' for i in range(meta['count'])]
    for path in paths:
        with Image.open(path) as image:
            assert image.mode == 'RGBA' and image.size == (512,512), str(path)
        count += 1
print(f'OK: {len(manifest)} registered poses and {count} layered PNG assets')
