"""Split this project's original 3x2 transparent character sheet into state PNGs.

Usage: python scripts/split_character_sheet.py
Requires: Pillow (pip install pillow)
"""
from pathlib import Path
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "assets" / "source-character-sheet.png"
TARGET = ROOT / "public" / "pet"

# Crop rectangles are fitted to the image delivered with this project.
SLICES = {
    "idle": (0, 0, 505, 545),
    "thinking": (505, 0, 950, 545),
    "working": (950, 0, 1448, 545),
    "attention": (0, 545, 505, 1086),
    "complete": (505, 545, 1005, 1086),
    "error": (1005, 545, 1448, 1086),
}


def run():
    image = Image.open(SOURCE).convert("RGBA")
    if image.size != (1448, 1086):
        raise RuntimeError(f"Unexpected sheet size: {image.size}; expected 1448x1086")
    TARGET.mkdir(parents=True, exist_ok=True)
    for name, rect in SLICES.items():
        frame = image.crop(rect)
        box = frame.getchannel("A").getbbox()
        if box is None:
            raise RuntimeError(f"Slice {name} contains no visible pixels")
        frame = frame.crop(box)
        frame.thumbnail((470, 470), Image.Resampling.LANCZOS)
        canvas = Image.new("RGBA", (512, 512), (0, 0, 0, 0))
        # Stable baseline helps visual transitions between the six poses.
        canvas.alpha_composite(frame, ((512 - frame.width) // 2, 500 - frame.height))
        output = TARGET / f"{name}.png"
        canvas.save(output, optimize=True)
        print(f"{name}: {frame.width}x{frame.height} -> {output.relative_to(ROOT)}")


if __name__ == "__main__":
    run()
