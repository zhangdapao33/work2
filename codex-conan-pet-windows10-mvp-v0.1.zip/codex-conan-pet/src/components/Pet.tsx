import { PET_DEFINITIONS, type PetState } from "../lib/pet";

interface PetProps {
  state: PetState;
  onClick: () => void;
}

export default function Pet({ state, onClick }: PetProps) {
  const definition = PET_DEFINITIONS[state];
  return (
    <div className={`pet-stage pet-stage--${state}`}>
      <div className="pet-halo" aria-hidden="true" />
      <button className="pet-character" type="button" onClick={onClick} title="点击柯南：切换到下一个状态" aria-label="点击角色，切换到下一个演示状态">
        <img src={definition.image} draggable={false} alt={`柯南 · ${definition.label}状态`} />
      </button>
      <div className={`pet-speech pet-speech--${state}`} role="status" aria-live="polite" aria-atomic="true">
        <span className="speech-dot" />{definition.speech}
      </div>
    </div>
  );
}
