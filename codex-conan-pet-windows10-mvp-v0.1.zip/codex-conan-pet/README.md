# 柯南 × Codex 桌宠（Windows 10）· MVP 0.1

这是一个仅供个人本地使用的 **Tauri 2 + React + TypeScript** 桌宠原型。

**本阶段已经实现**：6 种柯南形象及对应 PNG 素材、透明无边框/始终置顶的小窗口、拖动把手、按键/点击模拟状态切换、循环演示、收起控制面板、退出按钮、CSS 微动画。**尚未接入真实 Codex 事件**，这是下一阶段的开发内容。

> 注意：此项目仅用于个人本地研究演示，角色形象请勿未经授权对外传播或商用。

## 0. 先看效果（无需安装环境）

在解压后的项目根目录，双击 `预览演示.bat`（或直接双击 `demo.html`）。

此页面在浏览器里展示桌宠与六种状态切换，**并不是**透明置顶的桌面窗口；浏览器页面内不能拖动 Windows 原生窗口。真正的桌宠窗口需要完成下面的安装步骤。

## 1. Windows 10 系统环境

1. 安装 Node.js LTS（建议 20 或更高版本）。
2. 安装 Rust：访问 https://rustup.rs/，在 Windows 选择 MSVC（通常为 `x86_64-pc-windows-msvc`）工具链。
3. 安装 Microsoft Visual C++ Build Tools，勾选“使用 C++ 的桌面开发（Desktop development with C++）”。
4. 安装/确认 WebView2 Runtime；部分 Windows 10 已具备，缺少时安装 Microsoft Edge WebView2 Runtime。

参考官方前置要求：https://v2.tauri.app/start/prerequisites/

验证环境：在新打开的 PowerShell 中运行 `node -v`、`npm -v`、`cargo -V`。

## 2. 运行桌宠窗口

**最简单：** 双击 `启动桌宠-Windows.bat`。

或在项目根目录打开 PowerShell，执行：

```powershell
npm install
npm run tauri dev
```

首次运行需要联网安装 npm/Rust 依赖，耗时取决于网络与机器性能，之后重启更快。

> 部分 Windows 10 设备初次运行还需要 Windows SDK（由 Visual C++ Build Tools 的桌面 C++ 工作负载安装）。

## 3. 如何操作

| 操作 | 效果 |
| --- | --- |
| 按住顶部左侧 `⠿ CONAN.CODEX` | 拖动桌宠窗口 |
| 点击柯南身体 | 切换到下一状态 |
| 点击 6 个状态按钮 | 切换到对应角色表情 |
| 键盘 `1`~`6` | 快捷切换状态（窗口获取焦点时） |
| 空格 | 切到下一个状态（窗口获取焦点时） |
| “自动演示” | 每 1.7 秒循环切换 |
| 顶部 `− / +` | 收起或展开模拟控制台，同时调整窗口高度 |
| 顶部 `×` | 退出程序 |

启动后显示“模拟模式 / 尚未连接真实 CODEX”是正确的：此 MVP 的状态由用户按钮或自动演示控制，并不会读取 Codex 进程。

## 4. 打包安装包（在 Windows 10 本机执行）

双击 `打包Windows安装包.bat`，或执行：

```powershell
npm install
npm run tauri build
```

成功后在 `src-tauri/target/release/bundle/nsis/` 查找安装程序。

项目压缩包中提供**源码、素材和运行脚本**，**没有预先编译的 Windows EXE**；需要在 Windows 环境本地构建。

## 5. 文件结构

```text
codex-conan-pet/
├─ demo.html                   # 零安装浏览器演示
├─ 预览演示.bat
├─ 启动桌宠-Windows.bat
├─ 打包Windows安装包.bat
├─ package.json
├─ index.html
├─ src/
│  ├─ App.tsx                  # 模拟模式/交互逻辑
│  ├─ components/Pet.tsx       # 桌宠图像和气泡
│  ├─ lib/pet.ts               # 状态定义及素材映射
│  ├─ lib/petStore.ts          # Zustand 状态存储
│  ├─ lib/window.ts            # Tauri 窗口 API 适配
│  └─ styles/main.css          # UI 和微动画
├─ public/pet/*.png            # 6 张独立透明状态素材
├─ assets/source-character-sheet.png
├─ scripts/split_character_sheet.py
└─ src-tauri/
   ├─ tauri.conf.json          # 透明/置顶/无边框配置
   ├─ capabilities/default.json
   ├─ Cargo.toml
   ├─ build.rs
   ├─ src/main.rs
   └─ icons/                   # ICO 和多分辨率图标
```

## 6. 下一步：Codex 事件接入

建议新增 Codex CLI Hooks -> 本机 relay -> 统一事件 -> Zustand 状态机。

此版暂不包含 Hooks 配置、网络服务、Codex 日志读取或监控，也不传输代码/提示词。后续接入需要针对实际 Codex 版本验证支持的事件和配置，再实现事件去重、超时、多会话聚合。

## 7. 已知限制与排障

- 本版使用 **6 张静态姿势图 + CSS 微动效**，不是逐帧动画。
- 透明桌宠窗口需要在 Windows 上启动 `tauri dev`，而非 `npm run dev`（后者只启动网页开发服务器）。
- 浏览器单页演示不支持 Windows 原生拖动/置顶，也不会关掉整个浏览器。
- 画面不可见：优先检查 WebView2 安装；运行 `npm run tauri dev` 查看错误日志。
- 提示 `link.exe` / Windows SDK 缺失：安装或修复 Visual C++ Build Tools 的 C++ 桌面开发工作负载。
- PowerShell 提示运行 npm.ps1 受限：使用 CMD/批处理文件，或在 PowerShell 调用 `npm.cmd`。
- 角色透明边缘和人物姿势均源自生成的个人用素材，后续可替换为更精细的逐帧动画。
